package com.library.repository;

public class BookRepository {

    // Method to simulate fetching books
    public void fetchBooks() {
        System.out.println("Fetching books from the repository...");
    }
}
