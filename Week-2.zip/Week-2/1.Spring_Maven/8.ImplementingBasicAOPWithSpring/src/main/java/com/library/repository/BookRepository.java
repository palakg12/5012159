package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    // Repository logic for interacting with data source
}
